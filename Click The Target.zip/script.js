const target = document.getElementById("target");
const gameArea = document.getElementById("game-area");
const scoreDisplay = document.getElementById("score");
const timeDisplay = document.getElementById("time");
const startBtn = document.getElementById("startBtn");

let score = 0;
let timeLeft = 30;
let gameInterval;
let timer;

function randomPosition() {
  const x = Math.random() * (gameArea.clientWidth - target.clientWidth);
  const y = Math.random() * (gameArea.clientHeight - target.clientHeight);
  target.style.left = x + "px";
  target.style.top = y + "px";
}

target.addEventListener("click", () => {
  score++;
  scoreDisplay.textContent = score;
  randomPosition();
});

function startGame() {
  clearInterval(gameInterval);
  clearInterval(timer);

  score = 0;
  timeLeft = 30;

  scoreDisplay.textContent = score;
  timeDisplay.textContent = timeLeft;
  target.style.display = "block";

  randomPosition();

  gameInterval = setInterval(randomPosition, 1000);

  timer = setInterval(() => {
    timeLeft--;
    timeDisplay.textContent = timeLeft;

    if (timeLeft === 0) {
      endGame();
    }
  }, 1000);
}

function endGame() {
  clearInterval(gameInterval);
  clearInterval(timer);
  target.style.display = "none";
  alert("Game Over! Your score: " + score);
}

startBtn.addEventListener("click", startGame);